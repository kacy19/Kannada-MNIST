"""
Conditional GAN (cGAN) for Kannada MNIST digits.

Generator: noise + class label → 28×28×1 (tanh, so pixels in [-1, 1])
Discriminator: image + class label → real/fake logit

Training uses binary cross-entropy with label smoothing on the discriminator.
"""

from __future__ import annotations

import os
from typing import Dict, List, Optional, Tuple

import numpy as np
import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers

from config import LATENT_DIM, GAN_LR, GAN_BATCH, SEED, FIGURES_DIR, MODELS_DIR
from src.utils import ensure_dir, set_global_seed, mosaic_grid


def build_generator(latent_dim: int = LATENT_DIM, num_classes: int = 10) -> keras.Model:
    noise = keras.Input(shape=(latent_dim,), name="noise")
    label = keras.Input(shape=(1,), dtype="int32", name="label")

    # Embed label and concatenate with noise
    emb = layers.Embedding(num_classes, 50)(label)
    emb = layers.Flatten()(emb)
    x = layers.Concatenate()([noise, emb])

    x = layers.Dense(7 * 7 * 128, use_bias=False)(x)
    x = layers.BatchNormalization()(x)
    x = layers.LeakyReLU(0.2)(x)
    x = layers.Reshape((7, 7, 128))(x)

    x = layers.Conv2DTranspose(128, 4, strides=2, padding="same", use_bias=False)(x)
    x = layers.BatchNormalization()(x)
    x = layers.LeakyReLU(0.2)(x)          # 14×14

    x = layers.Conv2DTranspose(64, 4, strides=2, padding="same", use_bias=False)(x)
    x = layers.BatchNormalization()(x)
    x = layers.LeakyReLU(0.2)(x)          # 28×28

    img = layers.Conv2D(1, 3, padding="same", activation="tanh", name="generated")(x)
    return keras.Model([noise, label], img, name="generator")


def build_discriminator(num_classes: int = 10) -> keras.Model:
    img = keras.Input(shape=(28, 28, 1), name="image")
    label = keras.Input(shape=(1,), dtype="int32", name="label")

    # Embed label → 28×28×1 and concatenate as an extra channel
    emb = layers.Embedding(num_classes, 28 * 28)(label)
    emb = layers.Reshape((28, 28, 1))(emb)
    x = layers.Concatenate()([img, emb])   # 28×28×2

    x = layers.Conv2D(64, 3, strides=2, padding="same")(x)
    x = layers.LeakyReLU(0.2)(x)
    x = layers.Dropout(0.3)(x)

    x = layers.Conv2D(128, 3, strides=2, padding="same")(x)
    x = layers.LeakyReLU(0.2)(x)
    x = layers.Dropout(0.3)(x)

    x = layers.Flatten()(x)
    x = layers.Dense(1, name="real_fake")(x)   # logit
    return keras.Model([img, label], x, name="discriminator")


class ConditionalGAN:
    """Thin wrapper that owns generator, discriminator and the training step."""

    def __init__(
        self,
        latent_dim: int = LATENT_DIM,
        lr: float = GAN_LR,
        seed: int = SEED,
    ):
        set_global_seed(seed)
        self.latent_dim = latent_dim
        self.generator = build_generator(latent_dim)
        self.discriminator = build_discriminator()
        self.g_opt = keras.optimizers.Adam(lr, beta_1=0.5)
        self.d_opt = keras.optimizers.Adam(lr, beta_1=0.5)
        self.bce = keras.losses.BinaryCrossentropy(from_logits=True)
        self.history: Dict[str, List[float]] = {
            "g_loss": [], "d_loss": [], "d_acc_real": [], "d_acc_fake": []
        }
        # Fixed noise/labels for consistent sample grids
        self.fixed_noise = tf.random.normal((100, latent_dim), seed=seed)
        self.fixed_labels = tf.constant(
            np.repeat(np.arange(10), 10).reshape(-1, 1), dtype=tf.int32
        )

    def _d_loss(self, real_logits, fake_logits):
        # Label smoothing on real side
        real_labels = tf.ones_like(real_logits) * 0.9
        fake_labels = tf.zeros_like(fake_logits)
        return self.bce(real_labels, real_logits) + self.bce(fake_labels, fake_logits)

    def _g_loss(self, fake_logits):
        return self.bce(tf.ones_like(fake_logits), fake_logits)

    @tf.function
    def train_step(self, real_images, real_labels):
        batch = tf.shape(real_images)[0]
        noise = tf.random.normal((batch, self.latent_dim))

        with tf.GradientTape() as d_tape, tf.GradientTape() as g_tape:
            fake_images = self.generator([noise, real_labels], training=True)
            real_logits = self.discriminator([real_images, real_labels], training=True)
            fake_logits = self.discriminator([fake_images, real_labels], training=True)

            d_loss = self._d_loss(real_logits, fake_logits)
            g_loss = self._g_loss(fake_logits)

        d_grads = d_tape.gradient(d_loss, self.discriminator.trainable_variables)
        g_grads = g_tape.gradient(g_loss, self.generator.trainable_variables)
        self.d_opt.apply_gradients(zip(d_grads, self.discriminator.trainable_variables))
        self.g_opt.apply_gradients(zip(g_grads, self.generator.trainable_variables))

        d_acc_real = tf.reduce_mean(
            tf.cast(tf.sigmoid(real_logits) > 0.5, tf.float32)
        )
        d_acc_fake = tf.reduce_mean(
            tf.cast(tf.sigmoid(fake_logits) < 0.5, tf.float32)
        )
        return d_loss, g_loss, d_acc_real, d_acc_fake

    def fit(
        self,
        X: np.ndarray,
        y: np.ndarray,
        epochs: int,
        batch_size: int = GAN_BATCH,
        sample_every: int = 10,
        verbose: int = 1,
    ) -> Dict[str, List[float]]:
        """
        X must be in [0, 1].  Internally we map to [-1, 1] for tanh.
        """
        # Map [0,1] → [-1,1]
        X_gan = X * 2.0 - 1.0
        n = len(X_gan)
        steps = max(1, n // batch_size)

        for epoch in range(1, epochs + 1):
            # Shuffle
            idx = np.random.permutation(n)
            d_losses, g_losses, ar, af = [], [], [], []
            for s in range(steps):
                batch_idx = idx[s * batch_size : (s + 1) * batch_size]
                imgs = tf.convert_to_tensor(X_gan[batch_idx], dtype=tf.float32)
                labs = tf.convert_to_tensor(
                    y[batch_idx].reshape(-1, 1), dtype=tf.int32
                )
                d_l, g_l, a_r, a_f = self.train_step(imgs, labs)
                d_losses.append(float(d_l))
                g_losses.append(float(g_l))
                ar.append(float(a_r))
                af.append(float(a_f))

            self.history["d_loss"].append(float(np.mean(d_losses)))
            self.history["g_loss"].append(float(np.mean(g_losses)))
            self.history["d_acc_real"].append(float(np.mean(ar)))
            self.history["d_acc_fake"].append(float(np.mean(af)))

            if verbose:
                print(
                    f"Epoch {epoch:3d}/{epochs}  "
                    f"D={self.history['d_loss'][-1]:.4f}  "
                    f"G={self.history['g_loss'][-1]:.4f}  "
                    f"Dacc_real={self.history['d_acc_real'][-1]:.3f}  "
                    f"Dacc_fake={self.history['d_acc_fake'][-1]:.3f}"
                )

            if epoch == 1 or epoch == epochs // 2 or epoch == epochs:
                self.save_sample_grid(epoch)

        return self.history

    def generate(self, labels: np.ndarray, noise: Optional[np.ndarray] = None) -> np.ndarray:
        """
        Generate images for the given integer labels.
        Returns float32 images in [0, 1].
        """
        labels = np.asarray(labels, dtype=np.int32).reshape(-1, 1)
        n = len(labels)
        if noise is None:
            noise = np.random.normal(size=(n, self.latent_dim)).astype(np.float32)
        imgs = self.generator.predict([noise, labels], verbose=0)
        # tanh → [0,1]
        return np.clip((imgs + 1.0) / 2.0, 0.0, 1.0)

    def save_sample_grid(self, epoch: int) -> None:
        imgs = self.generate(
            self.fixed_labels.numpy().ravel(),
            noise=self.fixed_noise.numpy(),
        )
        path = os.path.join(FIGURES_DIR, f"gan_samples_epoch_{epoch:03d}.png")
        mosaic_grid(
            imgs,
            self.fixed_labels.numpy().ravel(),
            n_per_class=10,
            title=f"cGAN samples – epoch {epoch}",
            save_path=path,
        )
        print(f"[gan] sample grid saved → {path}")

    def save(self, prefix: str = "cgan") -> None:
        ensure_dir(MODELS_DIR)
        self.generator.save(os.path.join(MODELS_DIR, f"{prefix}_generator.keras"))
        self.discriminator.save(
            os.path.join(MODELS_DIR, f"{prefix}_discriminator.keras")
        )
