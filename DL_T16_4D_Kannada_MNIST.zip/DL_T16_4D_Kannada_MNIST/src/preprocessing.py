"""
Preprocessing, stratified splits and scarce-data simulation.
"""

from __future__ import annotations

from typing import Optional, Tuple

import numpy as np
from sklearn.model_selection import train_test_split

from config import SEED, VAL_FRACTION, REAL_PER_CLASS


def normalise(X: np.ndarray) -> np.ndarray:
    """uint8 (N,28,28) → float32 (N,28,28,1) in [0, 1]."""
    X = X.astype("float32") / 255.0
    if X.ndim == 3:
        X = X[..., None]
    return X


def denormalise(X: np.ndarray) -> np.ndarray:
    """[0,1] float → uint8 [0,255]."""
    if X.ndim == 4:
        X = X[..., 0]
    return np.clip(X * 255.0, 0, 255).astype(np.uint8)


def stratified_split(
    X: np.ndarray,
    y: np.ndarray,
    val_fraction: float = VAL_FRACTION,
    seed: int = SEED,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """Return X_train, X_val, y_train, y_val (stratified)."""
    return train_test_split(
        X, y, test_size=val_fraction, stratify=y, random_state=seed
    )


def subsample_per_class(
    X: np.ndarray,
    y: np.ndarray,
    n_per_class: Optional[int],
    seed: int = SEED,
) -> Tuple[np.ndarray, np.ndarray]:
    """
    Class-balanced subsample.  Used to simulate scarce real data
    so that synthetic augmentation has a chance to help.
    """
    if n_per_class is None:
        return X, y
    rng = np.random.default_rng(seed)
    indices = []
    for c in range(10):
        idx = np.where(y == c)[0]
        take = min(n_per_class, len(idx))
        chosen = rng.choice(idx, size=take, replace=False)
        indices.append(chosen)
    indices = np.concatenate(indices)
    rng.shuffle(indices)
    return X[indices], y[indices]


def prepare_splits(
    X_train_raw: np.ndarray,
    y_train_raw: np.ndarray,
    X_test_raw: np.ndarray,
    y_test_raw: np.ndarray,
    n_real_per_class: Optional[int] = REAL_PER_CLASS,
    seed: int = SEED,
) -> dict:
    """
    Full pipeline:
      - normalise
      - stratified val split from official train
      - scarce-data subsample on the remaining train pool
      - keep official test untouched
    """
    X_all = normalise(X_train_raw)
    y_all = y_train_raw.astype(np.int32)
    X_te = normalise(X_test_raw)
    y_te = y_test_raw.astype(np.int32)

    X_pool, X_val, y_pool, y_val = stratified_split(X_all, y_all, seed=seed)
    X_real, y_real = subsample_per_class(X_pool, y_pool, n_real_per_class, seed)

    return {
        "X_real": X_real,
        "y_real": y_real,
        "X_val": X_val,
        "y_val": y_val,
        "X_test": X_te,
        "y_test": y_te,
        "n_real": len(X_real),
        "n_val": len(X_val),
        "n_test": len(X_te),
    }
