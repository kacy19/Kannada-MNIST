"""
Kannada MNIST dataset download, IDX parsing and validation.

Official source: Zenodo record 3359691
https://zenodo.org/records/3359691

The record ships the four classic IDX gzip files inside
Kannada_MNIST_Ubyte_gz.zip.  We also support the TensorFlow-friendly
Kannada_MNIST_npz.zip as a fallback.
"""

from __future__ import annotations

import gzip
import os
import struct
import urllib.request
import zipfile
from typing import Tuple

import numpy as np

from config import DATA_DIR, ZENODO_ZIP_URL, ZENODO_TF_ZIP_URL, SEED
from src.utils import ensure_dir, set_global_seed


def _download(url: str, dest: str, timeout: int = 180) -> None:
    ensure_dir(os.path.dirname(dest) or ".")
    if os.path.exists(dest) and os.path.getsize(dest) > 0:
        print(f"[dataset] already present: {dest}")
        return
    print(f"[dataset] downloading {url}")
    req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
    with urllib.request.urlopen(req, timeout=timeout) as resp, open(dest, "wb") as f:
        f.write(resp.read())
    print(f"[dataset] saved {dest} ({os.path.getsize(dest)/1e6:.1f} MB)")


def _read_idx_images(path: str) -> np.ndarray:
    """Read IDX3 (images) file, gzipped or plain."""
    opener = gzip.open if path.endswith(".gz") else open
    with opener(path, "rb") as f:
        magic, n, rows, cols = struct.unpack(">IIII", f.read(16))
        if magic != 2051:
            raise ValueError(f"Bad magic for images: {magic}")
        data = np.frombuffer(f.read(), dtype=np.uint8)
        return data.reshape(n, rows, cols)


def _read_idx_labels(path: str) -> np.ndarray:
    """Read IDX1 (labels) file, gzipped or plain."""
    opener = gzip.open if path.endswith(".gz") else open
    with opener(path, "rb") as f:
        magic, n = struct.unpack(">II", f.read(8))
        if magic != 2049:
            raise ValueError(f"Bad magic for labels: {magic}")
        return np.frombuffer(f.read(), dtype=np.uint8)


def _find_idx_files(root: str) -> dict:
    """Locate the four classic IDX files under root (recursive)."""
    wanted = {
        "train-images": None,
        "train-labels": None,
        "t10k-images": None,
        "t10k-labels": None,
    }
    for dirpath, _, files in os.walk(root):
        for fn in files:
            low = fn.lower()
            full = os.path.join(dirpath, fn)
            if "train-images" in low and "idx" in low:
                wanted["train-images"] = full
            elif "train-labels" in low and "idx" in low:
                wanted["train-labels"] = full
            elif ("t10k-images" in low or "test-images" in low) and "idx" in low:
                wanted["t10k-images"] = full
            elif ("t10k-labels" in low or "test-labels" in low) and "idx" in low:
                wanted["t10k-labels"] = full
    return wanted


def download_and_extract() -> str:
    """
    Download the official Ubyte archive (or TF fallback) and extract.
    Returns the directory that contains the IDX files.
    """
    ensure_dir(DATA_DIR)
    ubyte_zip = os.path.join(DATA_DIR, "Kannada_MNIST_Ubyte_gz.zip")
    tf_zip = os.path.join(DATA_DIR, "Kannada_MNIST_npz.zip")

    # Prefer the classic IDX packaging
    try:
        _download(ZENODO_ZIP_URL, ubyte_zip)
        extract_dir = os.path.join(DATA_DIR, "ubyte")
        ensure_dir(extract_dir)
        with zipfile.ZipFile(ubyte_zip, "r") as zf:
            zf.extractall(extract_dir)
        found = _find_idx_files(extract_dir)
        if all(found.values()):
            return extract_dir
        print("[dataset] Ubyte archive did not contain expected IDX files, trying TF zip…")
    except Exception as e:
        print(f"[dataset] Ubyte download/extract failed: {e}")

    # Fallback: TensorFlow-friendly .npz archive
    try:
        _download(ZENODO_TF_ZIP_URL, tf_zip)
        extract_dir = os.path.join(DATA_DIR, "npz")
        ensure_dir(extract_dir)
        with zipfile.ZipFile(tf_zip, "r") as zf:
            zf.extractall(extract_dir)
        return extract_dir
    except Exception as e:
        msg = (
            f"Automatic download failed ({e}).\n"
            "Manual recovery:\n"
            f"  1. Open https://zenodo.org/records/3359691\n"
            f"  2. Download Kannada_MNIST_Ubyte_gz.zip or Kannada_MNIST_npz.zip\n"
            f"  3. Place the zip inside {DATA_DIR} and re-run.\n"
            "Do NOT substitute another dataset (e.g. Dig-MNIST or regular MNIST)."
        )
        raise RuntimeError(msg) from e


def load_from_idx(extract_dir: str) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    found = _find_idx_files(extract_dir)
    missing = [k for k, v in found.items() if v is None]
    if missing:
        raise FileNotFoundError(f"Missing IDX files: {missing} under {extract_dir}")
    X_train = _read_idx_images(found["train-images"])
    y_train = _read_idx_labels(found["train-labels"])
    X_test = _read_idx_images(found["t10k-images"])
    y_test = _read_idx_labels(found["t10k-labels"])
    return X_train, y_train, X_test, y_test


def load_from_npz(extract_dir: str) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """Load from Kannada_MNIST_npz.zip layout."""
    files = []
    for dirpath, _, fnames in os.walk(extract_dir):
        for fn in fnames:
            if fn.endswith(".npz"):
                files.append(os.path.join(dirpath, fn))
    if not files:
        raise FileNotFoundError(f"No .npz files under {extract_dir}")

    def pick(kind: str, split: str):
        for f in files:
            b = os.path.basename(f).lower()
            if kind in b and split in b and "dig" not in b:
                return f
        raise FileNotFoundError(f"No {kind}/{split} among {[os.path.basename(x) for x in files]}")

    def load_arr(path):
        d = np.load(path)
        a = d[d.files[0]]
        if a.ndim == 2 and a.shape[1] == 784:
            a = a.reshape(-1, 28, 28)
        return a

    X_train = load_arr(pick("x", "train"))
    y_train = load_arr(pick("y", "train")).astype(np.uint8).ravel()
    X_test = load_arr(pick("x", "test"))
    y_test = load_arr(pick("y", "test")).astype(np.uint8).ravel()
    return X_train, y_train, X_test, y_test


def load_kannada_mnist(force_download: bool = False) -> dict:
    """
    High-level loader.

    Returns dict with keys:
        X_train, y_train, X_test, y_test  (uint8, shape (N,28,28) / (N,))
    """
    set_global_seed(SEED)
    extract_dir = download_and_extract()

    # Detect packaging
    idx_files = _find_idx_files(extract_dir)
    if all(idx_files.values()):
        X_train, y_train, X_test, y_test = load_from_idx(extract_dir)
    else:
        X_train, y_train, X_test, y_test = load_from_npz(extract_dir)

    # Basic validation
    assert X_train.shape[1:] == (28, 28), X_train.shape
    assert X_test.shape[1:] == (28, 28), X_test.shape
    assert len(X_train) == len(y_train)
    assert len(X_test) == len(y_test)
    assert set(np.unique(y_train)) == set(range(10))
    assert set(np.unique(y_test)) == set(range(10))

    print(f"[dataset] train {X_train.shape}  test {X_test.shape}")
    print(f"[dataset] train label counts: {np.bincount(y_train).tolist()}")
    print(f"[dataset] test  label counts: {np.bincount(y_test).tolist()}")

    # Expected sizes (official Kannada-MNIST)
    if len(X_train) != 60000 or len(X_test) != 10000:
        print(
            f"[dataset] WARNING: sizes {len(X_train)}/{len(X_test)} "
            "differ from published 60000/10000 – investigate before using results."
        )

    return {
        "X_train": X_train.astype(np.uint8),
        "y_train": y_train.astype(np.int32),
        "X_test": X_test.astype(np.uint8),
        "y_test": y_test.astype(np.int32),
    }


if __name__ == "__main__":
    data = load_kannada_mnist()
    print("OK", {k: v.shape for k, v in data.items()})
