"""
CNN classifier used for baseline, synthetic-augmentation and adversarial training.
"""

from __future__ import annotations

from typing import Optional, Tuple

import numpy as np
import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers

from config import LEARNING_RATE, CNN_PATIENCE, BATCH_SIZE, SEED
from src.utils import set_global_seed


def build_cnn(seed: int = SEED, name: str = "cnn") -> keras.Model:
    """
    Compact CNN (~0.4 M parameters):
      32-32-pool → 64-pool → Flatten → Dropout → Dense(128) → Dropout → 10 logits
    Softmax is applied at loss / prediction time (from_logits=True).
    """
    set_global_seed(seed)
    inputs = keras.Input(shape=(28, 28, 1), name="image")
    x = layers.Conv2D(32, 3, padding="same", activation="relu")(inputs)
    x = layers.BatchNormalization()(x)
    x = layers.Conv2D(32, 3, padding="same", activation="relu")(x)
    x = layers.MaxPooling2D()(x)
    x = layers.Dropout(0.25)(x)

    x = layers.Conv2D(64, 3, padding="same", activation="relu")(x)
    x = layers.BatchNormalization()(x)
    x = layers.MaxPooling2D()(x)
    x = layers.Dropout(0.25)(x)

    x = layers.Flatten()(x)
    x = layers.Dense(128, activation="relu", name="feat")(x)
    x = layers.Dropout(0.4)(x)
    logits = layers.Dense(10, name="logits")(x)
    model = keras.Model(inputs, logits, name=name)
    return model


def compile_cnn(model: keras.Model, lr: float = LEARNING_RATE) -> keras.Model:
    model.compile(
        optimizer=keras.optimizers.Adam(lr),
        loss=keras.losses.SparseCategoricalCrossentropy(from_logits=True),
        metrics=["accuracy"],
    )
    return model


def train_cnn(
    model: keras.Model,
    X: np.ndarray,
    y: np.ndarray,
    X_val: np.ndarray,
    y_val: np.ndarray,
    epochs: int,
    batch_size: int = BATCH_SIZE,
    patience: int = CNN_PATIENCE,
    checkpoint_path: Optional[str] = None,
    verbose: int = 1,
) -> Tuple[keras.Model, dict]:
    callbacks = [
        keras.callbacks.EarlyStopping(
            monitor="val_loss",
            patience=patience,
            restore_best_weights=True,
            verbose=0,
        ),
        keras.callbacks.ReduceLROnPlateau(
            monitor="val_loss", factor=0.5, patience=max(2, patience // 2), verbose=0
        ),
    ]
    if checkpoint_path:
        callbacks.append(
            keras.callbacks.ModelCheckpoint(
                checkpoint_path,
                monitor="val_loss",
                save_best_only=True,
                verbose=0,
            )
        )
    history = model.fit(
        X, y,
        validation_data=(X_val, y_val),
        epochs=epochs,
        batch_size=batch_size,
        callbacks=callbacks,
        verbose=verbose,
    )
    return model, history.history


def predict_classes(model: keras.Model, X: np.ndarray, batch: int = 1024) -> np.ndarray:
    logits = model.predict(X, batch_size=batch, verbose=0)
    return np.argmax(logits, axis=1)


def evaluate_classifier(
    model: keras.Model,
    X: np.ndarray,
    y: np.ndarray,
) -> dict:
    from sklearn.metrics import (
        accuracy_score,
        confusion_matrix,
        precision_recall_fscore_support,
        classification_report,
    )
    pred = predict_classes(model, X)
    acc = float(accuracy_score(y, pred))
    p, r, f1, s = precision_recall_fscore_support(
        y, pred, labels=list(range(10)), zero_division=0
    )
    cm = confusion_matrix(y, pred, labels=list(range(10)))
    report = classification_report(
        y, pred, labels=list(range(10)), digits=4, zero_division=0
    )
    per_class_acc = cm.diagonal() / cm.sum(axis=1).clip(min=1)
    return {
        "accuracy": acc,
        "precision": p,
        "recall": r,
        "f1": f1,
        "support": s,
        "macro_f1": float(f1.mean()),
        "cm": cm,
        "per_class_acc": per_class_acc,
        "report": report,
        "pred": pred,
    }
