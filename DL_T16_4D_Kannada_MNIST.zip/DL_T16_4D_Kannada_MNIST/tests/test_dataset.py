"""Lightweight tests that do not require TensorFlow or the real download."""

import os
import sys
import struct
import gzip
import tempfile
import numpy as np

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

from src.dataset import _read_idx_images, _read_idx_labels


def _write_fake_idx(tmpdir):
    """Create tiny valid IDX files for unit testing."""
    n, rows, cols = 20, 28, 28
    # images
    img_path = os.path.join(tmpdir, "train-images-idx3-ubyte.gz")
    with gzip.open(img_path, "wb") as f:
        f.write(struct.pack(">IIII", 2051, n, rows, cols))
        f.write(np.random.randint(0, 256, size=n * rows * cols, dtype=np.uint8).tobytes())
    # labels
    lab_path = os.path.join(tmpdir, "train-labels-idx1-ubyte.gz")
    with gzip.open(lab_path, "wb") as f:
        f.write(struct.pack(">II", 2049, n))
        f.write(np.random.randint(0, 10, size=n, dtype=np.uint8).tobytes())
    return img_path, lab_path


def test_idx_roundtrip():
    with tempfile.TemporaryDirectory() as td:
        img_p, lab_p = _write_fake_idx(td)
        X = _read_idx_images(img_p)
        y = _read_idx_labels(lab_p)
        assert X.shape == (20, 28, 28)
        assert y.shape == (20,)
        assert X.dtype == np.uint8
        assert y.dtype == np.uint8
        assert set(np.unique(y)).issubset(set(range(10)))


def test_normalise_shape():
    from src.preprocessing import normalise
    X = np.random.randint(0, 256, size=(5, 28, 28), dtype=np.uint8)
    Xn = normalise(X)
    assert Xn.shape == (5, 28, 28, 1)
    assert Xn.dtype == np.float32
    assert 0.0 <= Xn.min() and Xn.max() <= 1.0


def test_mix_ratio_math():
    from src.synthetic_data import mix_real_synthetic
    Xr = np.zeros((100, 28, 28, 1), dtype=np.float32)
    yr = np.zeros(100, dtype=np.int32)
    Xs = np.ones((500, 28, 28, 1), dtype=np.float32)
    ys = np.tile(np.arange(10), 50)
    Xc, yc = mix_real_synthetic(Xr, yr, Xs, ys, 0.10)
    # n_syn ≈ 0.1/0.9 * 100 ≈ 11
    assert abs(len(Xc) - 111) <= 2
    Xc0, yc0 = mix_real_synthetic(Xr, yr, Xs, ys, 0.0)
    assert len(Xc0) == 100


if __name__ == "__main__":
    test_idx_roundtrip()
    test_normalise_shape()
    test_mix_ratio_math()
    print("test_dataset: all passed")
