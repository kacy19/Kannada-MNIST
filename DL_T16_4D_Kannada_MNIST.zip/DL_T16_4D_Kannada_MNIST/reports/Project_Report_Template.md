# GAN-Based Data Synthesis and Robustness Audit for a Kannada Character Recogniser

**Task 4 · Variant 4D · Team 16**  
CM701PC Deep Learning / CM751PC Deep Learning Laboratory  
Department of Emerging Technologies  
Mahatma Gandhi Institute of Technology (Autonomous), Hyderabad  
B.Tech CSE (AI & ML), VII Semester · Academic Year 2026–27

---

## Team members and contributions

| Roll number | Allotted role | Contribution |
|-------------|---------------|--------------|
| 23261A6620  | Data lead     | (fill) |
| 23261A6605  | Model lead    | (fill) |
| 23261A6614  | Evaluation & report lead | (fill) |

---

## 1. Abstract

*(3–5 sentences. State the problem, the method, the key quantitative findings from **your** run, and whether the three assignment targets were met.)*

---

## 2. Introduction and problem statement

Handwritten Kannada digit recognition is a classic multi-class image classification task. When labelled real data are scarce, generative models can synthesise additional training examples. The same classifier must also survive small adversarial perturbations (FGSM). This project investigates both questions on the official Kannada-MNIST dataset.

---

## 3. Objectives

1. Build a baseline CNN on real Kannada-MNIST data only.  
2. Train a conditional GAN and generate 25 000 labelled synthetic digits.  
3. Measure the effect of 0 %, 10 % and 25 % synthetic data on validation and test accuracy, with special attention to the three weakest classes.  
4. Evaluate the selected model under FGSM at eight epsilon values.  
5. Train an adversarially robust CNN and compare clean vs. adversarial accuracy.

---

## 4. Dataset

- Source: Zenodo 3359691 (Prabhu, arXiv:1908.01242).  
- 60 000 train / 10 000 test, 28×28 grayscale, 10 classes.  
- Dig-MNIST excluded.  
- Stratified 10 % validation split taken from the official training set.  
- Scarce-data simulation: `REAL_PER_CLASS` images per class used for training (state the number you used).  
- Official test set never used for model selection.

*(Insert class-distribution bar chart and sample-image grid from `outputs/figures/`.)*

---

## 5. Baseline CNN

Architecture:  
`Conv(32)–BN–Conv(32)–Pool–Drop → Conv(64)–BN–Pool–Drop → Flatten–Dense(128)–Drop–10 logits`  
Adam, sparse categorical cross-entropy (from logits), early stopping on validation loss.

*(Insert training curves and confusion matrix. Report validation and test accuracy, macro-F1, and the three weakest classes chosen from **validation** F1.)*

---

## 6. Conditional GAN

Generator: noise (100-d) + label embedding → Dense → reshape 7×7×128 → two transposed convolutions → tanh.  
Discriminator: image + label embedding (extra channel) → two strided convolutions → Dense(1).  
Loss: binary cross-entropy with 0.9 label smoothing on real samples.  
Adam (lr = 2e-4, β₁ = 0.5).

*(Insert sample grids at early / mid / final epoch and generator / discriminator loss curves. Do **not** claim convergence unless the curves support it.)*

---

## 7. Synthetic data generation and quality

Exactly 25 000 images (2 500 per class) were generated.  

Quality checks beyond visual inspection:

- Classifier agreement (real-trained CNN predicts the intended label).  
- Per-class agreement.  
- Mean pairwise L2 distance (diversity).  
- Near-duplicate rate (L2 < 1 on flattened pixels).

*(Report the numbers from `outputs/metrics/synthetic_quality.json`. Emphasise that agreement is **not** proof of realism.)*

---

## 8. Synthetic-ratio experiments

Three training sets:

| Ratio | Definition | Combined size (approx.) |
|-------|------------|-------------------------|
| 0 %   | real only  | n_real |
| 10 %  | n_syn = 0.1/0.9 × n_real | … |
| 25 %  | n_syn = 0.25/0.75 × n_real | … |

Best ratio chosen by **validation accuracy only**. Test numbers reported once.

*(Insert comparison table and discussion of the three weakest classes.)*

---

## 9. FGSM robustness audit

$$
x_{\text{adv}} = \mathrm{clip}\bigl(x + \varepsilon\cdot\mathrm{sign}(\nabla_x L(\theta,x,y)),\,0,\,1\bigr)
$$

ε ∈ {0, 0.02, 0.04, 0.06, 0.08, 0.10, 0.15, 0.20}. Main target ε = 0.10.

*(Insert accuracy-vs-ε curve, clean/adversarial image pairs, class-wise accuracy at ε = 0.10.)*

---

## 10. Adversarial training

Each step minimises ½ L(clean) + ½ L(FGSM(x, y, ε=0.10)).  
Early stopping on a combined validation score.

*(Insert final comparison table: baseline / selected synthetic / adversarial – clean accuracy, FGSM@0.10, other epsilons, precision, recall, F1.)*

---

## 11. Answers to the three assignment questions

### Q1 – Measuring generated sample quality beyond visual inspection

Classifier agreement, class-distribution match, diversity (pairwise distances), near-duplicate detection, and the limitations of each measure.

*(Write ½–1 page in your own words.)*

### Q2 – The GAN minimax game and a too-strong discriminator

Generator and discriminator objectives, the value function, vanishing gradients when D becomes perfect, and how loss curves diagnose imbalance.

*(Write ½–1 page.)*

### Q3 – FGSM, linear accuracy drop, and public-service checks

The FGSM equation, why the first-order Taylor expansion produces an approximately linear drop for moderate ε, and two concrete public-service examples that use handwritten character recognition (e.g. automated cheque processing, postal code reading) where robustness testing matters.

*(Write ½–1 page.)*

---

## 12. Limitations

*(Scarce-data simulation, single-step attack only, seed sensitivity, hardware dependence, …)*

---

## 13. Conclusion

*(2–3 sentences summarising what worked, what did not, and the honest status of the three targets.)*

---

## 14. References

1. Prabhu, V. (2019). Kannada-MNIST. Zenodo. https://doi.org/10.5281/zenodo.3359691  
2. Goodfellow, I. et al. (2014). Generative Adversarial Nets. NeurIPS.  
3. Goodfellow, I. et al. (2015). Explaining and Harnessing Adversarial Examples. ICLR.  
4. Mirza, M. & Osindero, S. (2014). Conditional Generative Adversarial Nets. arXiv:1411.1784.  
*(add any other papers or documentation you consulted)*

---

## Appendix A – AI-assistant usage

*(Required by the assignment. State which tools were used and for which parts of the work.)*

## Appendix B – Contribution table (detailed)

*(Expand the table from the title page if needed.)*
