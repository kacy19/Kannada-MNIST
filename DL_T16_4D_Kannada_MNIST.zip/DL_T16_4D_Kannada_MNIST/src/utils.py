"""
Utility helpers: seeds, directories, plotting helpers, JSON/CSV I/O.
"""

from __future__ import annotations

import json
import os
import random
from typing import Any, Dict, List, Optional

import numpy as np
import matplotlib.pyplot as plt


def set_global_seed(seed: int = 42) -> None:
    """Seed Python, NumPy and (if available) TensorFlow."""
    random.seed(seed)
    np.random.seed(seed)
    os.environ["PYTHONHASHSEED"] = str(seed)
    try:
        import tensorflow as tf
        tf.random.set_seed(seed)
        # Also seed Keras backend if present
        try:
            from tensorflow.keras.utils import set_random_seed
            set_random_seed(seed)
        except Exception:
            pass
    except ImportError:
        pass


def ensure_dir(path: str) -> str:
    os.makedirs(path, exist_ok=True)
    return path


def save_json(obj: Any, path: str) -> None:
    ensure_dir(os.path.dirname(path) or ".")
    with open(path, "w", encoding="utf-8") as f:
        json.dump(obj, f, indent=2, default=str)


def load_json(path: str) -> Any:
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def plot_history(history, keys: List[str], title: str, save_path: Optional[str] = None):
    """Plot training curves from a Keras History object or dict."""
    hist = history.history if hasattr(history, "history") else history
    n = len(keys)
    fig, axes = plt.subplots(1, n, figsize=(5 * n, 4))
    if n == 1:
        axes = [axes]
    for ax, k in zip(axes, keys):
        if k in hist:
            ax.plot(hist[k], label=f"train {k}")
        vk = f"val_{k}"
        if vk in hist:
            ax.plot(hist[vk], label=f"val {k}")
        ax.set_title(k)
        ax.legend()
        ax.set_xlabel("epoch")
    fig.suptitle(title)
    plt.tight_layout()
    if save_path:
        ensure_dir(os.path.dirname(save_path) or ".")
        fig.savefig(save_path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    return fig


def save_confusion_matrix(cm: np.ndarray, class_names: List[str],
                          title: str, save_path: str) -> None:
    import seaborn as sns
    fig, ax = plt.subplots(figsize=(8, 6))
    sns.heatmap(cm, annot=True, fmt="d", cmap="Blues",
                xticklabels=class_names, yticklabels=class_names, ax=ax)
    ax.set_xlabel("Predicted")
    ax.set_ylabel("True")
    ax.set_title(title)
    plt.tight_layout()
    ensure_dir(os.path.dirname(save_path) or ".")
    fig.savefig(save_path, dpi=150, bbox_inches="tight")
    plt.close(fig)


def mosaic_grid(images: np.ndarray, labels: np.ndarray,
                n_per_class: int = 10, title: str = "",
                save_path: Optional[str] = None) -> None:
    """Create a class-wise image grid (rows = classes)."""
    rows = []
    for c in range(10):
        idx = np.where(labels == c)[0][:n_per_class]
        imgs = images[idx]
        if imgs.ndim == 4:
            imgs = imgs[..., 0]
        if len(imgs) < n_per_class:
            pad = np.zeros((n_per_class - len(imgs), 28, 28), dtype=imgs.dtype)
            imgs = np.concatenate([imgs, pad], axis=0)
        rows.append(np.concatenate(list(imgs), axis=1))
    grid = np.concatenate(rows, axis=0)
    fig, ax = plt.subplots(figsize=(12, 12))
    ax.imshow(grid, cmap="gray", vmin=0, vmax=1 if grid.max() <= 1.5 else 255)
    ax.set_title(title)
    ax.axis("off")
    plt.tight_layout()
    if save_path:
        ensure_dir(os.path.dirname(save_path) or ".")
        fig.savefig(save_path, dpi=150, bbox_inches="tight")
    plt.close(fig)
