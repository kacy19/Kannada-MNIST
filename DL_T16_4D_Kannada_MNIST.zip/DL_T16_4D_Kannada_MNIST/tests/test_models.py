"""Model construction smoke tests (require TensorFlow)."""

import os
import sys
import pytest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

tf = pytest.importorskip("tensorflow")


def test_cnn_builds():
    from src.models import build_cnn, compile_cnn
    m = build_cnn(seed=0)
    compile_cnn(m)
    assert m.output_shape == (None, 10)
    # Forward pass
    import numpy as np
    x = np.random.rand(4, 28, 28, 1).astype("float32")
    y = m.predict(x, verbose=0)
    assert y.shape == (4, 10)


def test_generator_discriminator_shapes():
    from src.gan import build_generator, build_discriminator
    g = build_generator(latent_dim=100)
    d = build_discriminator()
    import numpy as np
    noise = np.random.randn(8, 100).astype("float32")
    labels = np.zeros((8, 1), dtype="int32")
    imgs = g.predict([noise, labels], verbose=0)
    assert imgs.shape == (8, 28, 28, 1)
    assert imgs.min() >= -1.01 and imgs.max() <= 1.01
    logits = d.predict([imgs, labels], verbose=0)
    assert logits.shape == (8, 1)


if __name__ == "__main__":
    test_cnn_builds()
    test_generator_discriminator_shapes()
    print("test_models: all passed")
