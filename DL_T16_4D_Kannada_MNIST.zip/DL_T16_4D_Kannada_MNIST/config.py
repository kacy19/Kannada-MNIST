"""
Configuration for DL Task 4D – Kannada MNIST
Team 16 | MGIT Hyderabad | 2026–27
"""

import os

# ---------------------------------------------------------------------------
# Paths
# ---------------------------------------------------------------------------
PROJECT_ROOT = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(PROJECT_ROOT, "data")
OUTPUT_DIR = os.path.join(PROJECT_ROOT, "outputs")
FIGURES_DIR = os.path.join(OUTPUT_DIR, "figures")
METRICS_DIR = os.path.join(OUTPUT_DIR, "metrics")
TABLES_DIR = os.path.join(OUTPUT_DIR, "tables")
SAMPLES_DIR = os.path.join(OUTPUT_DIR, "generated_samples")
MODELS_DIR = os.path.join(PROJECT_ROOT, "models")

# ---------------------------------------------------------------------------
# Dataset
# ---------------------------------------------------------------------------
# Official Zenodo record 3359691 packages the four IDX files inside
# Kannada_MNIST_Ubyte_gz.zip (not four separate URLs).
ZENODO_RECORD = "3359691"
DATASET_ZIP_NAME = "Kannada_MNIST_Ubyte_gz.zip"
ZENODO_ZIP_URL = (
    f"https://zenodo.org/records/{ZENODO_RECORD}/files/{DATASET_ZIP_NAME}"
)
# Alternative TensorFlow-friendly archive (same source, different packaging)
ZENODO_TF_ZIP_URL = (
    "https://zenodo.org/records/3359691/files/Kannada_MNIST_npz.zip"
)

NUM_CLASSES = 10
IMG_SIZE = 28
CHANNELS = 1

# ---------------------------------------------------------------------------
# Reproducibility
# ---------------------------------------------------------------------------
SEED = 42

# ---------------------------------------------------------------------------
# Training defaults (override from notebook / CLI for quick checks)
# ---------------------------------------------------------------------------
# Use smaller values for a fast smoke test; set QUICK_CHECK=False for full run.
QUICK_CHECK = False

if QUICK_CHECK:
    REAL_PER_CLASS = 200          # scarce-data simulation
    CNN_EPOCHS = 5
    GAN_EPOCHS = 8
    ADV_EPOCHS = 4
    BATCH_SIZE = 64
    GAN_BATCH = 64
else:
    REAL_PER_CLASS = 600          # still scarce relative to full 60k
    CNN_EPOCHS = 30
    GAN_EPOCHS = 60
    ADV_EPOCHS = 20
    BATCH_SIZE = 128
    GAN_BATCH = 128

VAL_FRACTION = 0.10
LATENT_DIM = 100
CNN_PATIENCE = 6
LEARNING_RATE = 1e-3
GAN_LR = 2e-4

# Synthetic ratios: synthetic / (real + synthetic) * 100
SYNTHETIC_RATIOS = [0.0, 0.10, 0.25]
SYNTHETIC_TOTAL = 25000          # 2500 per class

# FGSM epsilons (pixel scale [0, 1])
EPS_LIST = [0.0, 0.02, 0.04, 0.06, 0.08, 0.10, 0.15, 0.20]
MAIN_EPS = 0.10

# ---------------------------------------------------------------------------
# Ensure directories exist
# ---------------------------------------------------------------------------
for d in [DATA_DIR, OUTPUT_DIR, FIGURES_DIR, METRICS_DIR,
          TABLES_DIR, SAMPLES_DIR, MODELS_DIR]:
    os.makedirs(d, exist_ok=True)
