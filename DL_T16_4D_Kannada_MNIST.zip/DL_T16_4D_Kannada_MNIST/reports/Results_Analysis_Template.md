# Results Analysis Worksheet – Team 16 / Task 4D

Fill every cell from the CSV/JSON files produced by **your** run.  
Do not invent numbers.

## 1. Baseline (real data only)

| Metric | Validation | Test |
|--------|------------|------|
| Accuracy | | |
| Macro-F1 | | |
| Three weakest classes (val F1) | | – |

## 2. Synthetic quality

| Quantity | Value |
|----------|-------|
| Overall classifier agreement | |
| Near-duplicate rate (L2 < 1) | |
| Mean pairwise L2 | |

## 3. Ratio comparison (validation used for selection)

| Ratio | n_train | Val acc | Val macro-F1 | Test acc | Test macro-F1 | Mean F1 of weak-3 |
|-------|---------|---------|--------------|----------|---------------|-------------------|
| 0 %   |         |         |              |          |               |                   |
| 10 %  |         |         |              |          |               |                   |
| 25 %  |         |         |              |          |               |                   |

**Selected ratio (by validation):** ________

## 4. FGSM sweep (selected clean model)

| ε     | Accuracy |
|-------|----------|
| 0.00  |          |
| 0.02  |          |
| 0.04  |          |
| 0.06  |          |
| 0.08  |          |
| 0.10  |          |
| 0.15  |          |
| 0.20  |          |

## 5. Final three-model comparison

| Model | Clean test acc | FGSM@0.10 | Macro-F1 |
|-------|----------------|-----------|----------|
| Baseline (0 % synthetic) | | | |
| Selected synthetic ratio | | | |
| Adversarially trained | | | |

## 6. Target checklist

| Target | Required | Measured | Met? |
|--------|----------|----------|------|
| Clean acc within 2 pp of best clean | ≤ 2 pp drop | | |
| FGSM@0.10 ≥ 60 % | ≥ 0.60 | | |
| Weak-3 improvement shown numerically | reported | | |

## 7. Honest discussion (½ page)

*(Why did synthetic data help / not help? Why did adversarial training succeed / fail the 2 pp constraint? What would you change next?)*
