# Validation summary – DL_T16_4D_Kannada_MNIST

Generated on packaging. Full GPU training was **not** executed in the packaging environment.

| Check | Result |
|-------|--------|
| Python syntax (`py_compile` + AST) | Passed for all `.py` files |
| Offline unit tests (`tests/test_dataset.py`) | 3 passed (IDX round-trip, normalise shape, mix-ratio math) |
| TensorFlow-dependent tests | Skipped here (TF not installed in packaging env); they run on Colab / local GPU |
| Notebook JSON | Valid (`nbformat` 4, 26 cells) |
| Required folders | `src/`, `notebooks/`, `reports/`, `tests/`, `data/`, `outputs/`, `models/` present |
| Fabricated metrics | None – report templates use placeholders only |
| Pretrained weights / synthetic `.npy` | Not included (generated at runtime) |

## How to re-validate after download

```bash
cd DL_T16_4D_Kannada_MNIST
pip install -r requirements.txt
python tests/test_dataset.py
python -c "import tensorflow; from tests import test_models, test_attacks"  # optional
python run_project.py --quick          # smoke pipeline
```

Then open the notebook, set `QUICK_CHECK = False`, and run the full experiment on a GPU.
