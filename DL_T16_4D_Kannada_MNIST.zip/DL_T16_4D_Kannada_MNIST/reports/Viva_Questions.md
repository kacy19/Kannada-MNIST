# Likely Viva Questions – Task 4D (Kannada MNIST)

Prepare short, precise answers. You may be asked to open any file and explain it line by line.

## Dataset & preprocessing
1. Why do we keep the official test set completely untouched until the very end?  
2. What does “scarce-data simulation” mean and why did we introduce it?  
3. How is the validation set created? Is it stratified?  
4. Why do we normalise pixels to [0, 1] for the CNN but map them to [−1, 1] for the GAN?

## CNN
5. Why do we use `from_logits=True` instead of a Softmax layer?  
6. What does Batch Normalisation do inside a convolutional block?  
7. How does early stopping decide which weights to keep?

## Conditional GAN
8. Write the high-level objectives of the generator and the discriminator.  
9. Why do we feed the class label to both networks?  
10. What happens to the generator gradient when the discriminator becomes perfect?  
11. Why do we keep a fixed noise vector for the sample grids?

## Synthetic data
12. How is the 10 % / 25 % synthetic fraction defined mathematically?  
13. Why is classifier agreement **not** a proof that the images are realistic?  
14. How would you detect mode collapse from the sample grids or the loss curves?

## FGSM & adversarial training
15. Write the FGSM update formula and explain each term.  
16. Why can accuracy fall roughly linearly with ε for small ε?  
17. In adversarial training we optimise ½ L(clean) + ½ L(adv). What would happen if we used only the adversarial term?  
18. Why is a multi-step PGD attack a stronger evaluation than FGSM?

## Experimental design
19. Which metric was used to choose the best synthetic ratio? Why not test accuracy?  
20. How were the three weakest classes identified?  
21. If the adversarial model drops more than 2 pp of clean accuracy, what do you report?

## Code navigation
22. Point to the exact place where the test set is excluded from training.  
23. Point to the FGSM gradient tape.  
24. Point to the line that guarantees exactly 25 000 synthetic images with balanced labels.
