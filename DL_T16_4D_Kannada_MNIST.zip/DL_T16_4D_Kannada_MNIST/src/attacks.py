"""
Fast Gradient Sign Method (FGSM) and evaluation helpers.

x_adv = clip(x + eps * sign(∇_x L(θ, x, y)), 0, 1)
"""

from __future__ import annotations

from typing import Dict, List, Optional

import numpy as np
import tensorflow as tf
from tensorflow import keras

from config import EPS_LIST, MAIN_EPS, FIGURES_DIR
from src.utils import ensure_dir
import matplotlib.pyplot as plt
import os


loss_per_sample = keras.losses.SparseCategoricalCrossentropy(
    from_logits=True, reduction="none"
)


def fgsm(
    model: keras.Model,
    x: tf.Tensor | np.ndarray,
    y: tf.Tensor | np.ndarray,
    eps: float,
) -> tf.Tensor:
    """Single-step FGSM.  x must be float32 in [0, 1]."""
    x = tf.convert_to_tensor(x, dtype=tf.float32)
    y = tf.convert_to_tensor(y, dtype=tf.int32)
    with tf.GradientTape() as tape:
        tape.watch(x)
        logits = model(x, training=False)
        loss = tf.reduce_sum(loss_per_sample(y, logits))
    grad = tape.gradient(loss, x)
    x_adv = x + eps * tf.sign(grad)
    return tf.clip_by_value(x_adv, 0.0, 1.0)


def attack_accuracy(
    model: keras.Model,
    X: np.ndarray,
    y: np.ndarray,
    eps: float,
    batch_size: int = 256,
) -> float:
    """Accuracy of model on FGSM-perturbed (or clean if eps=0) images."""
    n = len(X)
    correct = 0
    for i in range(0, n, batch_size):
        xb = X[i : i + batch_size]
        yb = y[i : i + batch_size]
        if eps > 0:
            xa = fgsm(model, xb, yb, eps).numpy()
        else:
            xa = xb
        pred = model.predict(xa, batch_size=batch_size, verbose=0).argmax(1)
        correct += int((pred == yb).sum())
    return correct / n


def full_eps_sweep(
    model: keras.Model,
    X: np.ndarray,
    y: np.ndarray,
    eps_list: List[float] = None,
) -> Dict[str, float]:
    if eps_list is None:
        eps_list = EPS_LIST
    results = {}
    for e in eps_list:
        acc = attack_accuracy(model, X, y, e)
        results[f"eps_{e:.2f}"] = acc
        print(f"  eps={e:.2f}  acc={acc:.4f}")
    return results


def fgsm_sanity_check(
    model: keras.Model,
    X: np.ndarray,
    y: np.ndarray,
    eps: float = 0.1,
    n: int = 128,
) -> None:
    """Quick assertions that the attack is implemented correctly."""
    xb, yb = X[:n], y[:n]
    xa = fgsm(model, xb, yb, eps).numpy()
    assert np.abs(xa - xb).max() <= eps + 1e-5, "perturbation exceeds eps"
    assert xa.min() >= -1e-6 and xa.max() <= 1 + 1e-6, "pixels left [0,1]"
    # Loss should increase
    l_clean = loss_per_sample(
        yb, model(xb, training=False)
    ).numpy().mean()
    l_adv = loss_per_sample(
        yb, model(xa, training=False)
    ).numpy().mean()
    assert l_adv >= l_clean - 1e-5, "loss did not increase – check gradient sign"
    print(
        f"[FGSM sanity] max|δ|={np.abs(xa-xb).max():.4f} ≤ {eps}, "
        f"loss {l_clean:.4f} → {l_adv:.4f}  OK"
    )


def visualise_attack(
    model: keras.Model,
    X: np.ndarray,
    y: np.ndarray,
    eps: float = MAIN_EPS,
    n: int = 8,
    title: str = "FGSM",
    save_path: Optional[str] = None,
) -> None:
    xb, yb = X[:n], y[:n]
    xa = fgsm(model, xb, yb, eps).numpy()
    p0 = model.predict(xb, verbose=0).argmax(1)
    p1 = model.predict(xa, verbose=0).argmax(1)
    fig, axes = plt.subplots(3, n, figsize=(1.5 * n, 5))
    for i in range(n):
        axes[0, i].imshow(xb[i, ..., 0], cmap="gray", vmin=0, vmax=1)
        axes[0, i].set_title(f"y={yb[i]}\np={p0[i]}", fontsize=7)
        axes[1, i].imshow(xa[i, ..., 0], cmap="gray", vmin=0, vmax=1)
        axes[1, i].set_title(f"adv p={p1[i]}", fontsize=7)
        axes[2, i].imshow(
            (xa - xb)[i, ..., 0], cmap="bwr", vmin=-eps, vmax=eps
        )
        for r in range(3):
            axes[r, i].axis("off")
    fig.suptitle(f"{title}  (ε={eps})")
    plt.tight_layout()
    if save_path is None:
        save_path = os.path.join(FIGURES_DIR, f"fgsm_examples_eps{eps:.2f}.png")
    ensure_dir(os.path.dirname(save_path) or ".")
    fig.savefig(save_path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    print(f"[attack] visualisation → {save_path}")
