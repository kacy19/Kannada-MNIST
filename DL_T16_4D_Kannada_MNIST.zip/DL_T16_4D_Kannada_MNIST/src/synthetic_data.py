"""
Generate exactly 25 000 labelled synthetic Kannada digits and run
basic quality checks (classifier agreement, diversity, near-duplicates).
"""

from __future__ import annotations

import os
from typing import Dict, Optional, Tuple

import numpy as np
import pandas as pd

from config import SAMPLES_DIR, SYNTHETIC_TOTAL, FIGURES_DIR
from src.utils import ensure_dir, mosaic_grid, save_json
# predict_classes imported lazily inside quality_audit (avoids TF at import time)


def generate_balanced_synthetic(
    gan,
    n_total: int = SYNTHETIC_TOTAL,
    seed: int = 42,
) -> Tuple[np.ndarray, np.ndarray]:
    """
    Produce exactly n_total images,  n_total // 10  per class.
    Returns X_syn (float32 [0,1]), y_syn (int32).
    """
    assert n_total % 10 == 0
    per_class = n_total // 10
    rng = np.random.default_rng(seed)
    labels = np.repeat(np.arange(10), per_class)
    noise = rng.normal(size=(n_total, gan.latent_dim)).astype(np.float32)
    # Shuffle so consecutive batches are mixed
    perm = rng.permutation(n_total)
    labels = labels[perm]
    noise = noise[perm]
    X_syn = gan.generate(labels, noise=noise)
    assert X_syn.shape == (n_total, 28, 28, 1)
    assert X_syn.min() >= 0.0 and X_syn.max() <= 1.0
    return X_syn.astype(np.float32), labels.astype(np.int32)


def save_synthetic(
    X_syn: np.ndarray,
    y_syn: np.ndarray,
    tag: str = "synthetic_25k",
) -> Dict[str, str]:
    ensure_dir(SAMPLES_DIR)
    npy_path = os.path.join(SAMPLES_DIR, f"{tag}_images.npy")
    lab_path = os.path.join(SAMPLES_DIR, f"{tag}_labels.npy")
    csv_path = os.path.join(SAMPLES_DIR, f"{tag}_index.csv")
    np.save(npy_path, X_syn)
    np.save(lab_path, y_syn)
    pd.DataFrame({"id": np.arange(len(y_syn)), "label": y_syn}).to_csv(
        csv_path, index=False
    )
    # Visual grid
    grid_path = os.path.join(FIGURES_DIR, f"{tag}_grid.png")
    mosaic_grid(X_syn, y_syn, n_per_class=10, title=tag, save_path=grid_path)
    return {"images": npy_path, "labels": lab_path, "csv": csv_path, "grid": grid_path}


def quality_audit(
    X_syn: np.ndarray,
    y_syn: np.ndarray,
    real_classifier,
    X_real: Optional[np.ndarray] = None,
    max_pairs: int = 2000,
) -> Dict:
    """
    1. Classifier agreement: fraction of synthetic images whose predicted
       class matches the intended label (using a CNN trained only on real data).
    2. Per-class agreement.
    3. Simple diversity: mean pairwise L2 distance among a random subset.
    4. Near-duplicate rate (L2 < threshold on flattened pixels).
    """
    from src.models import predict_classes
    pred = predict_classes(real_classifier, X_syn)
    agree = pred == y_syn
    overall = float(agree.mean())
    per_class = {}
    for c in range(10):
        mask = y_syn == c
        per_class[int(c)] = float(agree[mask].mean()) if mask.any() else 0.0

    # Diversity & near-duplicates on a random subset (memory-friendly)
    rng = np.random.default_rng(0)
    n = min(max_pairs, len(X_syn))
    idx = rng.choice(len(X_syn), size=n, replace=False)
    flat = X_syn[idx].reshape(n, -1)
    # Sample pairs
    n_pairs = min(5000, n * (n - 1) // 2)
    i1 = rng.integers(0, n, size=n_pairs)
    i2 = rng.integers(0, n, size=n_pairs)
    mask = i1 != i2
    i1, i2 = i1[mask], i2[mask]
    dists = np.linalg.norm(flat[i1] - flat[i2], axis=1)
    mean_dist = float(dists.mean()) if len(dists) else 0.0
    near_dup_rate = float((dists < 1.0).mean()) if len(dists) else 0.0

    report = {
        "n_samples": int(len(X_syn)),
        "overall_agreement": overall,
        "per_class_agreement": per_class,
        "mean_pairwise_l2": mean_dist,
        "near_duplicate_rate_l2_lt_1": near_dup_rate,
        "note": (
            "Classifier agreement measures how often a real-trained CNN "
            "assigns the intended label; it is NOT proof of visual realism."
        ),
    }
    return report


def mix_real_synthetic(
    X_real: np.ndarray,
    y_real: np.ndarray,
    X_syn: np.ndarray,
    y_syn: np.ndarray,
    synthetic_fraction: float,
    seed: int = 42,
) -> Tuple[np.ndarray, np.ndarray]:
    """
    Build a combined training set where
        synthetic_fraction = n_syn / (n_real + n_syn)
    i.e. 0.0 → pure real, 0.10 → 10 % synthetic, 0.25 → 25 % synthetic.
    """
    if synthetic_fraction <= 0.0:
        return X_real.copy(), y_real.copy()
    n_real = len(X_real)
    # n_syn / (n_real + n_syn) = f  ⇒  n_syn = f/(1-f) * n_real
    n_syn = int(round(synthetic_fraction / (1.0 - synthetic_fraction) * n_real))
    n_syn = min(n_syn, len(X_syn))
    rng = np.random.default_rng(seed)
    # Balanced draw from synthetic pool
    per = n_syn // 10
    chosen = []
    for c in range(10):
        idx = np.where(y_syn == c)[0]
        take = min(per, len(idx))
        chosen.append(rng.choice(idx, size=take, replace=False))
    chosen = np.concatenate(chosen)
    if len(chosen) < n_syn:  # fill remainder randomly
        extra = rng.choice(
            np.setdiff1d(np.arange(len(X_syn)), chosen),
            size=n_syn - len(chosen),
            replace=False,
        )
        chosen = np.concatenate([chosen, extra])
    X_c = np.concatenate([X_real, X_syn[chosen]], axis=0)
    y_c = np.concatenate([y_real, y_syn[chosen]], axis=0)
    perm = rng.permutation(len(X_c))
    return X_c[perm], y_c[perm]
