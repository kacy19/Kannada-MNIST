# DL Task 4D – GAN-Based Data Synthesis and Robustness Audit for Kannada MNIST

**Team 16** | Mahatma Gandhi Institute of Technology (MGIT), Hyderabad  
**Department of Emerging Technologies** | B.Tech CSE (AI & ML), VII Semester  
**Academic Year 2026–27**  
**Course:** CM701PC Deep Learning / CM751PC Deep Learning Laboratory  
**Variant:** 4D – Kannada numerals

---

## 1. Project objective

1. Train a CNN that recognises Kannada handwritten digits (0–9).  
2. Train a **Conditional GAN (cGAN)** that generates additional labelled Kannada digits.  
3. Measure whether adding synthetic images (0 %, 10 %, 25 % of the combined training set) improves classification, especially on the three weakest classes.  
4. Audit the selected model with the **Fast Gradient Sign Method (FGSM)** at eight epsilon values.  
5. Train a second CNN with **adversarial training** and compare clean vs. adversarial accuracy.

All design decisions (architecture, ratio, early-stopping) are made on the **validation set only**. The official test set is used once, after all choices are frozen.

---

## 2. Dataset

- **Source:** Zenodo record 3359691 – *Kannada-MNIST* (Prabhu, arXiv:1908.01242).  
- **Files:** the four classic IDX gzip files packaged inside `Kannada_MNIST_Ubyte_gz.zip`.  
- **Sizes:** 60 000 train / 10 000 test, 28×28 grayscale, 10 classes.  
- **Dig-MNIST is ignored** (different writers, out-of-domain).  

The loader downloads the archive automatically. If the download fails, place the zip manually in `data/` and re-run (see `data/README.md`).

---

## 3. Project layout

```
DL_T16_4D_Kannada_MNIST/
├── README.md
├── requirements.txt
├── config.py                 # all hyper-parameters in one place
├── run_project.py            # headless full pipeline
├── .gitignore
├── notebooks/
│   └── Kannada_MNIST_Task_4D_Complete.ipynb
├── src/
│   ├── dataset.py            # download + IDX parsing
│   ├── preprocessing.py
│   ├── models.py             # CNN
│   ├── gan.py                # cGAN
│   ├── synthetic_data.py
│   ├── evaluation.py
│   ├── attacks.py            # FGSM
│   ├── adversarial_training.py
│   └── utils.py
├── reports/
│   ├── Project_Report_Template.md
│   ├── Results_Analysis_Template.md
│   └── Viva_Questions.md
├── outputs/                  # created at runtime
│   ├── figures/
│   ├── metrics/
│   ├── tables/
│   └── generated_samples/
├── models/                   # .keras checkpoints
├── data/                     # downloaded archives (not shipped)
└── tests/
    ├── test_dataset.py
    ├── test_models.py
    └── test_attacks.py
```

---

## 4. Quick start (Google Colab)

1. Upload `DL_T16_4D_Kannada_MNIST.zip` to Colab (or clone the folder).  
2. Runtime → Change runtime type → **GPU**.  
3. Open `notebooks/Kannada_MNIST_Task_4D_Complete.ipynb`.  
4. Set `QUICK_CHECK = True` in the first code cell and run all cells (a few minutes).  
5. When everything finishes without error, set `QUICK_CHECK = False` and run again for submission-quality results (expect 1–3 hours on a free Colab GPU, depending on epoch counts).

The notebook is self-contained: it installs dependencies, downloads the data, trains everything and writes all tables/figures under `outputs/`.

---

## 5. Local execution (VS Code / terminal)

```bash
# 1. Unzip
unzip DL_T16_4D_Kannada_MNIST.zip
cd DL_T16_4D_Kannada_MNIST

# 2. Environment
python -m venv .venv
source .venv/bin/activate          # Windows: .venv\Scripts\activate
pip install -r requirements.txt

# 3. Smoke test (no GPU required, ~2–5 min)
python -m pytest tests/ -q --ignore=tests/test_models.py --ignore=tests/test_attacks.py
python run_project.py --quick

# 4. Full run (GPU strongly recommended)
python run_project.py
```

---

## 6. Stages (what the code does)

| Stage | What happens |
|-------|----------------|
| 1 | Download Kannada MNIST, validate shapes, stratified val split, scarce-data subsample, sample grids |
| 2 | Baseline CNN on real data only → curves, confusion matrix, three weakest classes (from **validation** F1) |
| 3 | Conditional GAN (noise + label → image), sample grids at early / mid / final epoch, loss curves |
| 4 | Generate exactly 25 000 labelled synthetic images (2 500 / class), quality audit (classifier agreement, diversity, near-duplicates) |
| 5 | Three experiments: 0 %, 10 %, 25 % synthetic. Select best ratio by **validation** accuracy only, then report its test numbers once |
| 6 | FGSM at ε ∈ {0, 0.02, 0.04, 0.06, 0.08, 0.10, 0.15, 0.20}; accuracy-vs-ε plot; visual examples |
| 7 | Online adversarial training (½ clean + ½ FGSM loss); compare baseline / selected / adversarial models |

---

## 7. Performance targets (assignment)

These are **targets**, not guarantees. Report the actual numbers you obtain.

- Clean test accuracy of the adversarially trained model within **2 percentage points** of the best clean model.  
- FGSM accuracy at ε = 0.10 ideally ≥ **60 %**.  
- Synthetic data ideally improves the three weakest baseline classes.

If a target is missed, explain why honestly; do not tune on the test set or invent metrics.

---

## 8. Reproducibility

- Global seed (`config.SEED = 42`) is applied to Python, NumPy and TensorFlow.  
- Validation set is stratified and fixed before any model selection.  
- Test set is never used for early stopping, ratio selection or hyper-parameter search.  
- All metrics are written to CSV/JSON under `outputs/`; the report templates contain placeholders that you fill from those files.

---

## 9. Expected runtimes (approximate)

| Mode | Hardware | Wall time |
|------|----------|-----------|
| `QUICK_CHECK=True` | CPU / free Colab | 3–8 min |
| Full run | Colab T4 GPU | 1–3 h |
| Full run | CPU only | 6–12 h |

GAN training is the slowest stage; reduce `GAN_EPOCHS` in `config.py` if you need a faster iteration.

---

## 10. Limitations (be honest in the report)

- Scarce-data simulation (`REAL_PER_CLASS`) is a deliberate design choice so that synthetic data has room to help; with the full 60 k real images a GAN is unlikely to improve accuracy.  
- Classifier agreement is **not** a proof of visual realism.  
- FGSM is a single-step attack; a multi-step PGD evaluation would be a stronger robustness test.  
- Results depend on random seeds and hardware; always re-run with the submitted code.

---

## 11. AI-assistant declaration (required by the assignment)

If you used any AI coding assistant (including the one that generated this skeleton), list it in an appendix of the report and be ready to explain any line of code in the viva.

---

## 12. Troubleshooting

| Symptom | Fix |
|---------|-----|
| Download fails | Place `Kannada_MNIST_Ubyte_gz.zip` manually in `data/` |
| OOM on GPU | Lower `BATCH_SIZE` / `GAN_BATCH` in `config.py` |
| Very slow on CPU | Keep `QUICK_CHECK=True` while debugging |
| Import errors | Run from the project root so that `src/` is importable |

---

**Team 16 – MGIT Hyderabad – 2026–27**
