# Dataset – Kannada MNIST

**Official source:** Zenodo record 3359691  
https://zenodo.org/records/3359691

Paper: Prabhu, “Kannada-MNIST: A new handwritten digits dataset for the Kannada language” (arXiv:1908.01242).

## Files used by this project

The record ships the classic IDX gzip files inside a single archive:

- `Kannada_MNIST_Ubyte_gz.zip`  
  contains  
  - `train-images-idx3-ubyte.gz`  
  - `train-labels-idx1-ubyte.gz`  
  - `t10k-images-idx3-ubyte.gz`  
  - `t10k-labels-idx1-ubyte.gz`

A TensorFlow-friendly packaging (`Kannada_MNIST_npz.zip`) is also accepted as a fallback.

**We deliberately ignore Dig-MNIST** (an out-of-domain set of 10 240 images).  
Only the original 60 000 / 10 000 train / test split is used.

## Automatic download

```python
from src.dataset import load_kannada_mnist
data = load_kannada_mnist()
```

If the download fails (network, Zenodo downtime, etc.) the loader prints a clear message and the manual recovery steps:

1. Open https://zenodo.org/records/3359691  
2. Download `Kannada_MNIST_Ubyte_gz.zip` (or the TensorFlow zip)  
3. Place it inside this `data/` folder and re-run.

Do **not** substitute regular MNIST, Fashion-MNIST or any other dataset.

## Licence / citation

Check the Zenodo page for the exact licence terms before including the dataset in a public repository or publication. Cite the original paper and the Zenodo DOI.
