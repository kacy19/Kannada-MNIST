#!/usr/bin/env python3
"""
Command-line entry point for the full Kannada MNIST pipeline.
Prefer the notebook for interactive exploration; this script is for
headless / batch runs (e.g. after QUICK_CHECK has been verified).
"""

from __future__ import annotations

import argparse
import os
import sys

# Make sure project root is on the path
ROOT = os.path.dirname(os.path.abspath(__file__))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

import config
from src.utils import set_global_seed


def main():
    parser = argparse.ArgumentParser(description="DL Task 4D – Kannada MNIST")
    parser.add_argument("--quick", action="store_true",
                        help="Tiny run for syntax / smoke testing")
    parser.add_argument("--stages", type=str, default="all",
                        help="Comma-separated stages: 1,2,3,4,5,6,7 or 'all'")
    args = parser.parse_args()

    if args.quick:
        config.QUICK_CHECK = True
        # Re-apply the small defaults
        config.REAL_PER_CLASS = 200
        config.CNN_EPOCHS = 5
        config.GAN_EPOCHS = 8
        config.ADV_EPOCHS = 4
        config.BATCH_SIZE = 64
        config.GAN_BATCH = 64
        print("*** QUICK_CHECK mode – results are NOT for submission ***")

    set_global_seed(config.SEED)

    # Import after config is possibly modified
    from src.dataset import load_kannada_mnist
    from src.preprocessing import prepare_splits
    from src.models import build_cnn, compile_cnn, train_cnn, evaluate_classifier
    from src.gan import ConditionalGAN
    from src.synthetic_data import (
        generate_balanced_synthetic, save_synthetic, quality_audit, mix_real_synthetic
    )
    from src.evaluation import weak_classes_from_f1, save_eval, comparison_table
    from src.attacks import full_eps_sweep, fgsm_sanity_check, visualise_attack
    from src.adversarial_training import train_adversarially
    from src.utils import plot_history, mosaic_grid, save_json
    import numpy as np
    import pandas as pd

    stages = set(args.stages.split(",")) if args.stages != "all" else set("1234567")

    # ------------------------------------------------------------------
    # Stage 1 – Data
    # ------------------------------------------------------------------
    print("\n=== STAGE 1: Dataset ===")
    raw = load_kannada_mnist()
    splits = prepare_splits(
        raw["X_train"], raw["y_train"],
        raw["X_test"], raw["y_test"],
        n_real_per_class=config.REAL_PER_CLASS,
    )
    X_real, y_real = splits["X_real"], splits["y_real"]
    X_val, y_val = splits["X_val"], splits["y_val"]
    X_test, y_test = splits["X_test"], splits["y_test"]
    print(f"real={len(X_real)}  val={len(X_val)}  test={len(X_test)}")
    mosaic_grid(
        X_real, y_real, n_per_class=8,
        title="Real training samples",
        save_path=os.path.join(config.FIGURES_DIR, "01_real_samples.png"),
    )

    # ------------------------------------------------------------------
    # Stage 2 – Baseline CNN
    # ------------------------------------------------------------------
    print("\n=== STAGE 2: Baseline CNN ===")
    baseline = build_cnn(seed=config.SEED, name="baseline")
    compile_cnn(baseline)
    baseline, hist_base = train_cnn(
        baseline, X_real, y_real, X_val, y_val,
        epochs=config.CNN_EPOCHS,
        checkpoint_path=os.path.join(config.MODELS_DIR, "baseline.keras"),
    )
    plot_history(hist_base, ["loss", "accuracy"], "Baseline CNN",
                 os.path.join(config.FIGURES_DIR, "02_baseline_curves.png"))
    ev_val = evaluate_classifier(baseline, X_val, y_val)
    ev_test = evaluate_classifier(baseline, X_test, y_test)
    print(f"Baseline  val_acc={ev_val['accuracy']:.4f}  test_acc={ev_test['accuracy']:.4f}")
    save_eval(ev_test, "baseline_test")
    WEAK = weak_classes_from_f1(ev_val, k=3)
    print(f"Three weakest classes (validation F1): {WEAK}")
    save_json({"weak_classes": WEAK, "val_acc": ev_val["accuracy"],
               "test_acc": ev_test["accuracy"]},
              os.path.join(config.METRICS_DIR, "baseline_summary.json"))
    baseline.save(os.path.join(config.MODELS_DIR, "baseline_final.keras"))

    # ------------------------------------------------------------------
    # Stage 3 – cGAN
    # ------------------------------------------------------------------
    print("\n=== STAGE 3: Conditional GAN ===")
    gan = ConditionalGAN(seed=config.SEED)
    gan_hist = gan.fit(X_real, y_real, epochs=config.GAN_EPOCHS, verbose=1)
    gan.save("cgan")
    plot_history(gan_hist, ["g_loss", "d_loss"], "cGAN losses",
                 os.path.join(config.FIGURES_DIR, "03_gan_losses.png"))

    # ------------------------------------------------------------------
    # Stage 4 – 25 k synthetic images + quality audit
    # ------------------------------------------------------------------
    print("\n=== STAGE 4: Generate 25 000 synthetic images ===")
    X_syn, y_syn = generate_balanced_synthetic(gan, n_total=config.SYNTHETIC_TOTAL)
    paths = save_synthetic(X_syn, y_syn)
    print("Saved:", paths)
    quality = quality_audit(X_syn, y_syn, baseline, X_real=X_real)
    print("Quality:", {k: quality[k] for k in ("overall_agreement", "near_duplicate_rate_l2_lt_1")})
    save_json(quality, os.path.join(config.METRICS_DIR, "synthetic_quality.json"))

    # ------------------------------------------------------------------
    # Stage 5 – Synthetic-ratio experiments
    # ------------------------------------------------------------------
    print("\n=== STAGE 5: Synthetic-ratio experiments ===")
    ratio_rows = []
    models_by_ratio = {}
    for frac in config.SYNTHETIC_RATIOS:
        tag = f"ratio_{int(frac*100):02d}"
        print(f"\n--- {tag} (synthetic fraction = {frac:.0%}) ---")
        X_tr, y_tr = mix_real_synthetic(X_real, y_real, X_syn, y_syn, frac)
        print(f"  combined train size = {len(X_tr)}")
        m = build_cnn(seed=config.SEED, name=tag)
        compile_cnn(m)
        m, hist = train_cnn(m, X_tr, y_tr, X_val, y_val, epochs=config.CNN_EPOCHS)
        ev_v = evaluate_classifier(m, X_val, y_val)
        ev_t = evaluate_classifier(m, X_test, y_test)
        save_eval(ev_t, f"{tag}_test")
        models_by_ratio[frac] = m
        ratio_rows.append({
            "ratio": frac,
            "n_train": len(X_tr),
            "val_acc": ev_v["accuracy"],
            "val_macro_f1": ev_v["macro_f1"],
            "test_acc": ev_t["accuracy"],
            "test_macro_f1": ev_t["macro_f1"],
            "weak_f1_mean": float(np.mean([ev_t["f1"][c] for c in WEAK])),
        })
        m.save(os.path.join(config.MODELS_DIR, f"{tag}.keras"))

    ratio_df = comparison_table(
        ratio_rows, os.path.join(config.TABLES_DIR, "synthetic_ratio_comparison.csv")
    )
    print(ratio_df.to_string(index=False))
    # Select best by VALIDATION accuracy only
    best_idx = int(np.argmax([r["val_acc"] for r in ratio_rows]))
    BEST_RATIO = ratio_rows[best_idx]["ratio"]
    BEST_MODEL = models_by_ratio[BEST_RATIO]
    print(f"Best ratio by validation accuracy: {BEST_RATIO:.0%}")

    # ------------------------------------------------------------------
    # Stage 6 – FGSM robustness audit
    # ------------------------------------------------------------------
    print("\n=== STAGE 6: FGSM robustness audit ===")
    fgsm_sanity_check(BEST_MODEL, X_test, y_test, eps=config.MAIN_EPS)
    print("Clean / selected model:")
    sweep = full_eps_sweep(BEST_MODEL, X_test, y_test)
    visualise_attack(
        BEST_MODEL, X_test, y_test, eps=config.MAIN_EPS,
        title=f"Selected model (ratio {BEST_RATIO:.0%})",
        save_path=os.path.join(config.FIGURES_DIR, "06_fgsm_selected.png"),
    )
    save_json(sweep, os.path.join(config.METRICS_DIR, "fgsm_sweep_selected.json"))

    # ------------------------------------------------------------------
    # Stage 7 – Adversarial training
    # ------------------------------------------------------------------
    print("\n=== STAGE 7: Adversarial training ===")
    X_adv_tr, y_adv_tr = mix_real_synthetic(
        X_real, y_real, X_syn, y_syn, BEST_RATIO
    )
    adv_model, adv_hist = train_adversarially(
        X_adv_tr, y_adv_tr, X_val, y_val,
        eps=config.MAIN_EPS, epochs=config.ADV_EPOCHS,
    )
    adv_model.save(os.path.join(config.MODELS_DIR, "adversarial.keras"))
    print("Adversarially trained model – eps sweep:")
    adv_sweep = full_eps_sweep(adv_model, X_test, y_test)
    visualise_attack(
        adv_model, X_test, y_test, eps=config.MAIN_EPS,
        title="Adversarially trained",
        save_path=os.path.join(config.FIGURES_DIR, "07_fgsm_adv.png"),
    )
    save_json(adv_sweep, os.path.join(config.METRICS_DIR, "fgsm_sweep_adv.json"))

    # Final comparison table
    final_rows = []
    for name, model, ratio in [
        ("baseline_real_only", baseline, 0.0),
        (f"selected_ratio_{BEST_RATIO:.0%}", BEST_MODEL, BEST_RATIO),
        ("adversarial", adv_model, BEST_RATIO),
    ]:
        ev = evaluate_classifier(model, X_test, y_test)
        row = {
            "model": name,
            "synthetic_ratio": ratio,
            "clean_test_acc": ev["accuracy"],
            "macro_f1": ev["macro_f1"],
        }
        for e in config.EPS_LIST:
            row[f"fgsm_{e:.2f}"] = attack_accuracy(model, X_test, y_test, e)
        final_rows.append(row)
    final_df = comparison_table(
        final_rows, os.path.join(config.TABLES_DIR, "final_comparison.csv")
    )
    print("\n=== FINAL COMPARISON ===")
    print(final_df.to_string(index=False))
    print("\nDone. All metrics and figures are under outputs/.")


if __name__ == "__main__":
    main()
