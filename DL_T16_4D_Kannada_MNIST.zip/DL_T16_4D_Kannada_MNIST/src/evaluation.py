"""
Metrics, tables and weak-class analysis helpers.
"""

from __future__ import annotations

import os
from typing import Dict, List, Optional

import numpy as np
import pandas as pd

from config import TABLES_DIR, METRICS_DIR, FIGURES_DIR
from src.utils import ensure_dir, save_json, save_confusion_matrix
from src.models import evaluate_classifier


def weak_classes_from_f1(eval_dict: dict, k: int = 3) -> List[int]:
    """Return the k classes with lowest F1 (chosen on validation only)."""
    f1 = eval_dict["f1"]
    return [int(c) for c in np.argsort(f1)[:k]]


def metrics_to_dataframe(eval_dict: dict) -> pd.DataFrame:
    return pd.DataFrame(
        {
            "precision": eval_dict["precision"],
            "recall": eval_dict["recall"],
            "f1": eval_dict["f1"],
            "support": eval_dict["support"],
            "per_class_acc": eval_dict["per_class_acc"],
        }
    ).rename_axis("class")


def save_eval(
    eval_dict: dict,
    name: str,
    class_names: Optional[List[str]] = None,
) -> None:
    ensure_dir(TABLES_DIR)
    ensure_dir(METRICS_DIR)
    ensure_dir(FIGURES_DIR)
    if class_names is None:
        class_names = [str(i) for i in range(10)]
    df = metrics_to_dataframe(eval_dict)
    df.to_csv(os.path.join(TABLES_DIR, f"{name}_per_class.csv"))
    save_json(
        {
            "accuracy": eval_dict["accuracy"],
            "macro_f1": eval_dict["macro_f1"],
        },
        os.path.join(METRICS_DIR, f"{name}_summary.json"),
    )
    with open(os.path.join(TABLES_DIR, f"{name}_report.txt"), "w") as f:
        f.write(eval_dict["report"])
    save_confusion_matrix(
        eval_dict["cm"],
        class_names,
        title=name,
        save_path=os.path.join(FIGURES_DIR, f"{name}_cm.png"),
    )


def comparison_table(rows: List[dict], path: str) -> pd.DataFrame:
    df = pd.DataFrame(rows)
    ensure_dir(os.path.dirname(path) or ".")
    df.to_csv(path, index=False)
    return df
