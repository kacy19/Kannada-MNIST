"""
DL Task 4D – Kannada MNIST source package
Team 16 | MGIT Hyderabad
"""

__version__ = "1.0.0"
