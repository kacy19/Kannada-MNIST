"""FGSM shape / clipping / loss-increase checks (require TensorFlow)."""

import os
import sys
import pytest
import numpy as np

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

tf = pytest.importorskip("tensorflow")


def test_fgsm_clip_and_direction():
    from src.models import build_cnn, compile_cnn
    from src.attacks import fgsm, fgsm_sanity_check

    m = build_cnn(seed=0)
    compile_cnn(m)
    X = np.random.rand(32, 28, 28, 1).astype("float32")
    y = np.random.randint(0, 10, size=32)
    # Sanity helper already asserts clipping and loss increase
    fgsm_sanity_check(m, X, y, eps=0.1, n=32)
    xa = fgsm(m, X, y, 0.05).numpy()
    assert xa.shape == X.shape
    assert xa.min() >= 0.0 and xa.max() <= 1.0


if __name__ == "__main__":
    test_fgsm_clip_and_direction()
    print("test_attacks: all passed")
