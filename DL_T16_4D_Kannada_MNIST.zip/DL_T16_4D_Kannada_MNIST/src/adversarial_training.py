"""
Online adversarial training with FGSM (ε = 0.10 by default).

Each training step minimises
    0.5 * L(clean) + 0.5 * L(FGSM(x, y, ε))
so that clean accuracy is protected while robustness is improved.
"""

from __future__ import annotations

from typing import Optional, Tuple

import numpy as np
import tensorflow as tf
from tensorflow import keras

from config import BATCH_SIZE, ADV_EPOCHS, MAIN_EPS, CNN_PATIENCE, SEED
from src.models import build_cnn, compile_cnn
from src.attacks import fgsm, attack_accuracy
from src.utils import set_global_seed


def train_adversarially(
    X: np.ndarray,
    y: np.ndarray,
    X_val: np.ndarray,
    y_val: np.ndarray,
    eps: float = MAIN_EPS,
    epochs: int = ADV_EPOCHS,
    batch_size: int = BATCH_SIZE,
    seed: int = SEED,
    patience: int = CNN_PATIENCE,
    verbose: int = 1,
) -> Tuple[keras.Model, dict]:
    """
    Returns the adversarially trained model and a simple history dict.
    Model selection uses a combined validation score
        0.5 * val_clean_acc + 0.5 * val_adv_acc
    with early stopping.
    """
    set_global_seed(seed)
    model = build_cnn(seed=seed, name="cnn_adv")
    opt = keras.optimizers.Adam(1e-3)
    loss_fn = keras.losses.SparseCategoricalCrossentropy(from_logits=True)

    ds = (
        tf.data.Dataset.from_tensor_slices((X, y.astype(np.int32)))
        .shuffle(len(X), seed=seed)
        .batch(batch_size)
        .prefetch(tf.data.AUTOTUNE)
    )

    @tf.function
    def train_step(xb, yb):
        xadv = fgsm(model, xb, yb, eps)
        with tf.GradientTape() as tape:
            loss_c = loss_fn(yb, model(xb, training=True))
            loss_a = loss_fn(yb, model(xadv, training=True))
            loss = 0.5 * loss_c + 0.5 * loss_a
        grads = tape.gradient(loss, model.trainable_variables)
        opt.apply_gradients(zip(grads, model.trainable_variables))
        return loss

    history = {"loss": [], "val_clean": [], "val_adv": []}
    best_score = -1.0
    best_weights = None
    wait = 0

    for epoch in range(1, epochs + 1):
        losses = []
        for xb, yb in ds:
            losses.append(float(train_step(xb, yb)))
        v_clean = attack_accuracy(model, X_val, y_val, 0.0)
        v_adv = attack_accuracy(model, X_val, y_val, eps)
        score = 0.5 * v_clean + 0.5 * v_adv
        history["loss"].append(float(np.mean(losses)))
        history["val_clean"].append(v_clean)
        history["val_adv"].append(v_adv)
        if verbose:
            print(
                f"Adv epoch {epoch:3d}/{epochs}  "
                f"loss={history['loss'][-1]:.4f}  "
                f"val_clean={v_clean:.4f}  val_adv@ε={v_adv:.4f}"
            )
        if score > best_score:
            best_score = score
            best_weights = model.get_weights()
            wait = 0
        else:
            wait += 1
            if wait >= patience:
                if verbose:
                    print(f"[adv] early stop at epoch {epoch}")
                break

    if best_weights is not None:
        model.set_weights(best_weights)
    return model, history
